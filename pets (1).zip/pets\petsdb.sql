-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-11-2022 a las 23:56:04
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `petsdb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `idMascota` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `edad` int(4) NOT NULL,
  `raza` varchar(100) NOT NULL,
  `postulaciones` int(3) NOT NULL,
  `idPersonal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`idMascota`, `nombre`, `edad`, `raza`, `postulaciones`, `idPersonal`) VALUES
(12, 'uwu', 1, 'uwu2', 1, 13),
(13, 'uwu', 1, 'uwu2', 1, 13),
(14, 'Pelusa', 10, 'coker', 2, 16),
(15, 'Pelusa', 10, 'coker', 2, 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `id` int(11) NOT NULL,
  `nombres` varchar(120) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `cedula` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`id`, `nombres`, `apellidos`, `direccion`, `correo`, `cedula`) VALUES
(13, 'Nixon Javier', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 0),
(14, 'Nixon Javier', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 959107705),
(15, 'Nixon Javier', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 1104384811),
(16, 'Jose', 'Alvarez', 'Loja', 'jose@gmail.com', 12341234),
(17, 'Jose', 'Alvarez', 'Loja', 'jose@gmail.com', 12341234),
(18, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(19, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(20, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(21, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(22, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(23, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(24, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134),
(25, 'bryan', 'Vuele Irene', 'Catamayo', 'nixonvuele51@gmail.com', 12342134);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`idMascota`),
  ADD KEY `idPersonal` (`idPersonal`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `mascota`
--
ALTER TABLE `mascota`
  MODIFY `idMascota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `mascota_ibfk_1` FOREIGN KEY (`idPersonal`) REFERENCES `personal` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
